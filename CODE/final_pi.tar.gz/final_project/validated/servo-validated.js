const shell = require('shelljs');
const fs = require('fs');
var ipfsClient = require('ipfs-http-client');

var ipfs = ipfsClient('localhost', '5001', {protocol: 'http'});
var topic = 'pi';

var started = false;
var validated = false;

publishMsg = (reply) => {
	ipfs.pubsub.publish(topic, Buffer.from(reply), (err) => {
		if (err) {
			return console.log(`failed to publish to ${topic}`, err);
		}
		console.log(`published "${reply}" to ${topic}`);
	});	
}

checkKeyId = (keyId) => {
	var user = shell.exec(`gpg --list-keys | grep -n ${keyId}`);
	if (user.code == 0) {
		return true;
	} else {
		return false;
	}
}	

const receiveMsg = (msg) => {
	var hash = msg.data.toString();

	if (hash === '/start') {
		publishMsg('send-me-your-key-id');
		started = true;
	}
	if (hash.indexOf('<<--') > -1 && hash.indexOf('-->>') > -1 && started) {
		var keyId = hash.substring(4, hash.length-4);
		if (checkKeyId(keyId)) {
			publishMsg('encryptedcomm');
			validated = true;
		} else {
			publishMsg(`${keyId}-not-found`);
		}
	}
	if (hash.substring(0,2) === 'Qm' && validated) {
		ipfs.get(hash, function(err, files) {
			if (err) {
				console.log('Error', err);
			};
			files.forEach((file) => {
				fs.writeFile('data.enc', file.content, (err) => {
					if (err) throw err;
					decryptMsg();
				});
			});
		});
	}
}

decryptMsg = () => {
	var text = shell.exec(`gpg --passphrase raspberry --decrypt data.enc`);
	if (text.stdout === 'on\n') {
		shell.exec('gpio pwm 1 150');
	} else {
		shell.exec('gpio pwm 1 250');
	}
}

ipfs.pubsub.subscribe(topic, receiveMsg, (err) => {
	if (err) {
		return console.log(`failed to subscribe to ${topic}`, err);
	}
	console.log(`subscribed to ${topic}`);
});
