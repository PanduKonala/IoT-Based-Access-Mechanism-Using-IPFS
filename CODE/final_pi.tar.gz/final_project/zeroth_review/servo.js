const shell = require('shelljs');
const Gpio = require('onoff').Gpio;
const fs = require('fs');
var ipfsClient = require('ipfs-http-client');

var ipfs = ipfsClient('localhost', '5001', {protocol: 'http'});
const LED = new Gpio(4, 'out');
var topic = 'pi';

fs.readFile('servo_state.txt', (err, data) => {
	if (err) {
		console.log(err);
	}
	console.log(`Last state of servo: ${data}`);
	console.log('*********************************************');
});

const receiveMsg = (msg) => {
	var hash = msg.data.toString();

	ipfs.get(hash, function(err, files) {
		files.forEach((file) => {
			console.log(file.content.toString('utf-8'));
			fs.writeFile('servo_state.txt', file.content.toString('utf-8'), () => {});
			if (file.content.toString('utf-8') === 'on\n') {
				shell.exec('gpio pwm 1 150');
			} else {
				shell.exec('gpio pwm 1 250');
			}
		});
	});
}


ipfs.pubsub.subscribe(topic, receiveMsg, (err) => {
	if (err) {
		return console.log(`failed to subscribe to ${topic}`, err);
	}
	console.log(`subscribed to ${topic}`);
});