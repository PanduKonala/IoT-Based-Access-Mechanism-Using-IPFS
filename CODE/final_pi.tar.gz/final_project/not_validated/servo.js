const shell = require('shelljs');
const fs = require('fs');
var ipfsClient = require('ipfs-http-client');

var ipfs = ipfsClient('localhost', '5001', {protocol: 'http'});
var topic = 'pi';


const receiveMsg = (msg) => {
	var hash = msg.data.toString();

	ipfs.get(hash, function(err, files) {
		files.forEach((file) => {
			fs.writeFile('data.enc', file.content, (err) => {
				if (err) throw err;
				console.log('The file has been saved!');
				decryptMsg();
			});
		});
	});
}

decryptMsg = () => {
	var text = shell.exec(`gpg --passphrase raspberry --decrypt data.enc`);
	if (text.stdout === 'on\n') {
		shell.exec('gpio pwm 1 150');
	} else {
		shell.exec('gpio pwm 1 250');
	}	
}

ipfs.pubsub.subscribe(topic, receiveMsg, (err) => {
	if (err) {
		return console.log(`failed to subscribe to ${topic}`, err);
	}
	console.log(`subscribed to ${topic}`);
});
