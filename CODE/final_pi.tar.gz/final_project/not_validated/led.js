const shell = require('shelljs');
const fs = require('fs');
const Gpio = require('onoff').Gpio;
var ipfsClient = require('ipfs-http-client');

var ipfs = ipfsClient('localhost', '5001', {protocol: 'http'});
const LED = new Gpio(4, 'out');
var topic = 'pi';

const receiveMsg = (msg) => {
	var hash = msg.data.toString();

	ipfs.get(hash, function(err, files) {
		files.forEach((file) => {
			fs.writeFile('data.enc', file.content, (err) => {
				if (err) throw err;
				decryptMsg();
			});
		});
	});
}

decryptMsg = () => {
	var text = shell.exec(`gpg --passphrase raspberry --decrypt data.enc`);
	if (text.stdout === 'on\n') {
		LED.writeSync(1);
	} else {
		LED.writeSync(0);
	}
	console.log('##########################################################');
}

ipfs.pubsub.subscribe(topic, receiveMsg, (err) => {
	if (err) {
		return console.log(`failed to subscribe to ${topic}`, err);
	}
	console.log(`subscribed to ${topic}`);
	console.log('##########################################################');
});
