gpio mode 1 pwm
gpio pwm-ms
gpio pwmc 192
gpio pwmr 2000

echo "GPIO enabled successfully"