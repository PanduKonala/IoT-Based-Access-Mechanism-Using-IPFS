
import io.ipfs.api.IPFS;
import io.ipfs.multiaddr.MultiAddress;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Base64;
import java.util.*;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Stream;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author bob
 */
public class pitst {
    
    public static IPFS ipfs = new IPFS(new MultiAddress("/ip4/127.0.0.1/tcp/5001"));  
    
    public static void servoControl(String opt) {
        String visited="false";        
        String input = opt;
        //Runtime runTime = Runtime.getRuntime();
        if(input.equals("open")){
            try {	
                if(visited.equals("false")){
                    /*runTime.exec("gpio mode 1 pwm");
                    runTime.exec("gpio pwm-ms");
                    runTime.exec("gpio pwmc 192"); 
                    runTime.exec("gpio pwmr 2000");*/
                }
                visited = "true";
                //runTime.exec("gpio pwm 1 150"); // ~center
                System.out.println("Opened");
            } catch (Exception e) {
                System.out.println("Exception occured: " + e.getMessage());
            }

        }
        else if(input.equals("close")){
            try {	
                if(visited.equals("false")){
                   /* runTime.exec("gpio mode 1 pwm");
                    runTime.exec("gpio pwm-ms");
                    runTime.exec("gpio pwmc 192"); 
                    runTime.exec("gpio pwmr 2000");*/
                }
                visited = "true";
                //runTime.exec("gpio pwm 1 250"); // turn left
                System.out.println("Closed");
            } catch (Exception e) {
                System.out.println("Exception occured: " + e.getMessage());
            }

        }
        else{
            System.exit(0);
        }
    }
    
    public static ArrayList<String> getGPGUIDs() { 
        ArrayList<String> al = new ArrayList<>();
        try{                       
            Process p1 = Runtime.getRuntime().exec("gpg --list-keys");
            BufferedReader in1 = new BufferedReader(
                new InputStreamReader(p1.getInputStream()));
            String line1 = null;
            int i = 1;
            while ((line1 = in1.readLine()) != null) {
                String a = line1;
                if(i%5 == 0) {
                    String temp = a.substring(a.indexOf("]")+2,a.indexOf("<")-1);
                    al.add(temp);
                }
                i++;
            }
        } catch (IOException ex) {
            Logger.getLogger(pitst.class.getName()).log(Level.SEVERE, null, ex);
        }
        return al;
    }
    
    public static boolean getObj(String objHash) {    
        //System.out.println("getting object: " + objHash); 
        try{  
            Process p1 = Runtime.getRuntime().exec("ipfs get"+" "+objHash);
            BufferedReader in1 = new BufferedReader(
                                new InputStreamReader(p1.getInputStream()));
            String line1 = null;
            while ((line1 = in1.readLine()) != null) {
              String a = line1;               
                //System.out.println(a); 
            }
            return true;
        }catch (IOException ex) {
            Logger.getLogger(pitst.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    public static boolean decryptObj(String objHash) {
        try{
            Process p2 = Runtime.getRuntime().exec("gpg --output"+" "+objHash+".dec"+" "+"--decrypt"+" "+objHash);
            BufferedReader in1 = new BufferedReader(
                 new InputStreamReader(p2.getInputStream()));
            String line1 = null;
            while ((line1 = in1.readLine()) != null) {
                String a = line1;
                //System.out.println(a);
            }
            return true;
        }catch (IOException ex) {
            Logger.getLogger(pitst.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    public static void readFile() {
        try{
            String a = null;
            String mycmd = "ls -t | head -n1";
            Process p2 = Runtime.getRuntime().exec(new String[] {"bash", "-c", mycmd});
            BufferedReader in1 = new BufferedReader(
                 new InputStreamReader(p2.getInputStream()));
            String line1 = null;
            while ((line1 = in1.readLine()) != null) {
                a = line1; 
                if(!(a.substring(a.length()-4,a.length()).equals(".dec"))) {
                    a = a + ".dec";
                }
                //System.out.println(a);
            }      

            Scanner scan = new Scanner(new File(a));
            while(scan.hasNextLine()) {
                //System.out.println(scan.nextLine());
                servoControl(scan.nextLine());
            }
            
        }catch (IOException ex) {
            Logger.getLogger(pitst.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public static String getMsg(String inputMsg) throws Exception {
        String resMsg;
        if(inputMsg.contains("<<--") && inputMsg.contains("-->>")) {            
            String uid = inputMsg.substring(4,inputMsg.length()-4);             
            ArrayList<String> gpguids = getGPGUIDs();          
            if(gpguids.contains(uid)) {
                System.out.println("Welcome to encrypted comm...");
                resMsg = "welcome-to-encrypted-communication";                
            }else {
                System.out.println("Profile not found!!!");
                resMsg = null;
            }
        }else if(inputMsg.startsWith("*") && inputMsg.endsWith("*")) {
            String objHash = inputMsg.substring(1, inputMsg.length()-1);
            boolean got = getObj(objHash);
            if(got) {
                //System.out.println("object: " + objHash + " downloaded");   
                boolean decrypted = decryptObj(objHash);
                if(decrypted) {
                    //System.out.println("object: " + objHash + " decrypted...!!!");
                    readFile();
                }
            }
            resMsg = "object-received";
        }else {
            switch(inputMsg) {
                case "/start":  resMsg = "do-you-have-keys?";
                                break;
                case "/yes":    resMsg = "send-me-your-key-id";                
                                break;
                case "/no":     resMsg = "this-is-my-key-please-download-it";
                                break;                
                default:        resMsg = null;
                                break;
            }
        }        
        return resMsg;
    }
    
     public static void main(String[] args) throws Exception {
        // TODO code application logic here
        try {
                                            
            while(true){
                String topic = "lol";

                Object sub1 = ipfs.pubsub.sub(topic);

                Stream<Map<String, Object>> sub2 = (Stream<Map<String, Object>>) sub1;
                 
                Object first = sub2.findAny();                
                String sub3 = ""+first; 

                String sub4[] = sub3.split(",");
                String data = sub4[1].substring(6,sub4[1].length());
                
                Base64.Decoder decoder = Base64.getDecoder();  
                String dStr = new String(decoder.decode(data)); 

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
              
                String msg = getMsg(dStr);                
                
                if(msg != null) {
                    ipfs.pubsub.pub(topic, msg);                     
                }
            }
        }catch (Exception ex) {
            Logger.getLogger(pitst.class.getName()).log(Level.SEVERE, null, ex);
        }                        
    }
}
